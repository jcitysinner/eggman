<footer id="site_footer">
<div class="wrapper">
		
	<a href="http://www.exsite.ca" id="credit">Site by Exsite Inc <svg><use xlink:href="#logo_exsite"></use></svg></a>
	
</div>
</footer>

<a href="index.php">Home</a> | 

<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/main.js"></script>
<?php 
  $url = 'http://' . $_SERVER['SERVER_NAME']; 
  echo '<script src="http://' . $_SERVER['SERVER_NAME'].':25711/livereload.js?snipver=1"></script>';
?>


</body>
</html>