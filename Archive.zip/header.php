<div class="sprite_hide">
	<?php include("img/sprite.svg"); ?>
</div>

<div id="head-container">
	<header id="site-header">
	
	<div id="logo_group" class="">
	<?php include("img/svg/compressed/logo_full_header.svg"); ?>
	<a href=""></a>
	</div>

	</header>
</div> 